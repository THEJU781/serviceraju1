<?php

return array (
  'dispute' => 
  array (
    'new_dispute' => '',
  ),
  'dispute_msgs' => 
  array (
    'delete' => '',
    'not_found' => '',
    'saved' => '',
    'update' => '',
  ),
  'favourite_location_msgs' => 
  array (
    'favourite_delete' => '',
    'favourite_exists' => '',
    'favourite_not_found' => '',
    'favourite_saved' => '',
    'favourite_update' => '',
  ),
  'lostitem_msgs' => 
  array (
    'delete' => '',
    'not_found' => '',
    'saved' => '',
    'update' => '',
  ),
  'notification_msgs' => 
  array (
    'delete' => '',
    'not_found' => '',
    'saved' => '',
    'update' => '',
  ),
  'request' => 
  array (
    'Booking_ID' => 'Booking ID',
    'Date_Time' => 'Date &amp; Time',
    'Payment_Mode' => 'Payment Mode',
    'Payment_Status' => 'Payment Status',
    'Provider_Name' => 'Tradee Name',
    'Request_Id' => 'Request Id',
    'Scheduled_Date_Time' => 'Scheduled Date & Time',
    'User_Name' => 'User Name',
    'base_price' => 'Base Price charge is fixed, Charge on each service request complete',
    'card_amount' => 'Card Amount',
    'cash_amount' => 'Cash Amount',
    'commission' => 'Commission',
    'date' => 'Dated on',
    'discount_price' => 'Discount Price',
    'distance_price' => 'Distance Price',
    'drop_address' => 'Drop Address',
    'dropped' => 'Dropped',
    'earned' => 'Earned',
    'fleet_commission' => 'Fleet Commission',
    'hours_price' => 'Hours Price',
    'minutes_price' => 'Minutes Price',
    'paid_amount' => 'Paid Amount',
    'payment_mode' => 'Payment Mode',
    'peak_amount' => 'Peak Hours Charge',
    'peak_commission' => 'Peak Hours Commission',
    'picked_up' => 'Picked up',
    'pickup_address' => 'Pickup Address',
    'provider_comment' => 'Tradee Comment',
    'provider_earnings' => 'Tradee Earnings',
    'provider_not_assigned' => 'Tradee not yet assigned!',
    'provider_rating' => 'Tradee Rating',
    'request_details' => 'Request Details',
    'ride_end_time' => 'Request End Time',
    'ride_scheduled_time' => 'Request Scheduled Time',
    'ride_start_time' => 'Request Start Time',
    'ride_status' => 'Request Status',
    'status' => 'Status',
    'surge_price' => 'Surge Price',
    'tax_price' => 'Tax Price',
    'tips' => 'Tips',
    'total_amount' => 'Total Amount',
    'total_distance' => 'Total Distance',
    'transaction_id' => 'Transaction ID',
    'user_comment' => 'User Comment',
    'user_rating' => 'User Rating',
    'waiting_charge' => 'Waiting Charge',
    'waiting_commission' => 'Waiting Charge Commission',
    'wallet_deduction' => 'Wallet Deduction',
  ),
  'review' => 
  array (
    'Comments' => 'Comments',
    'Provider_Reviews' => 'Tradee Reviews',
    'Rating' => 'Rating',
    'Request_ID' => 'Request ID',
    'User_Reviews' => 'User Reviews',
    'transaction_id' => 'Transaction ID',
  ),
  'email' => 
  array (
    'code_send_provider' => 'Verification code sent to your email!',
    'code_send_user' => 'Verification code sent to your email!',
  ),
);
